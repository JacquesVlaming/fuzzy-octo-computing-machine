# fortidlp Integration

## Overview

Explain what the integration is, define the third-party product that is providing data, establish its relationship to the larger ecosystem of Elastic products, and help the reader understand how it can be used to solve a tangible problem.
Check the [overview guidelines](https://www.elastic.co/guide/en/integrations-developer/current/documentation-guidelines.html#idg-docs-guidelines-overview) for more information.

## Datastreams


### fortidlp_stream

fortidlp_description


## Requirements

The requirements section helps readers to confirm that the integration will work with their systems.
Check the [requirements guidelines](https://www.elastic.co/guide/en/integrations-developer/current/documentation-guidelines.html#idg-docs-guidelines-requirements) for more information.

## Setup

Point the reader to the [Observability Getting started guide](https://www.elastic.co/guide/en/observability/master/observability-get-started.html) for generic, step-by-step instructions. Include any additional setup instructions beyond what’s included in the guide, which may include instructions to update the configuration of a third-party service.
Check the [setup guidelines](https://www.elastic.co/guide/en/integrations-developer/current/documentation-guidelines.html#idg-docs-guidelines-setup) for more information.

## Troubleshooting (optional)

Provide information about special cases and exceptions that aren’t necessary for getting started or won’t be applicable to all users. Check the [troubleshooting guidelines](https://www.elastic.co/guide/en/integrations-developer/current/documentation-guidelines.html#idg-docs-guidelines-troubleshooting) for more information.

## Reference

Provide detailed information about the log or metric types we support within the integration. Check the [reference guidelines](https://www.elastic.co/guide/en/integrations-developer/current/documentation-guidelines.html#idg-docs-guidelines-reference) for more information.

## Logs

### fortidlp_stream

fortidlp_description

**ECS Field Reference**

Please refer to the following [document](https://www.elastic.co/guide/en/ecs/current/ecs-field-reference.html) for detailed information on ECS fields.

**Exported fields**

| Field | Description | Type |
|---|---|---|
| @timestamp | Event timestamp. | date |
| cloud.image.id | Image ID for the cloud instance. | keyword |
| container.labels | Image labels. | object |
| data_stream.dataset | Data stream dataset name. | constant_keyword |
| data_stream.namespace | Data stream namespace. | constant_keyword |
| data_stream.type | Data stream type. | constant_keyword |
| event.dataset | Event dataset | constant_keyword |
| event.module | Event module | constant_keyword |
| fortidlp.fortidlp_stream.sensor.agent_hostname |  | keyword |
| fortidlp.fortidlp_stream.sensor.agent_uuid |  | keyword |
| fortidlp.fortidlp_stream.sensor.anonymised_description |  | keyword |
| fortidlp.fortidlp_stream.sensor.created_by.policy.group_id |  | keyword |
| fortidlp.fortidlp_stream.sensor.created_by.policy.instance |  | keyword |
| fortidlp.fortidlp_stream.sensor.created_by.policy.name |  | keyword |
| fortidlp.fortidlp_stream.sensor.created_by.policy.policy_id |  | keyword |
| fortidlp.fortidlp_stream.sensor.created_by.uri |  | keyword |
| fortidlp.fortidlp_stream.sensor.description |  | keyword |
| fortidlp.fortidlp_stream.sensor.extended_metadata.data.blocked |  | boolean |
| fortidlp.fortidlp_stream.sensor.extended_metadata.data.duration |  | long |
| fortidlp.fortidlp_stream.sensor.extended_metadata.data.num_files |  | long |
| fortidlp.fortidlp_stream.sensor.extended_metadata.data.readable |  | boolean |
| fortidlp.fortidlp_stream.sensor.extended_metadata.data.writeable |  | boolean |
| fortidlp.fortidlp_stream.sensor.extended_metadata.schema.id |  | keyword |
| fortidlp.fortidlp_stream.sensor.extended_metadata.schema.version |  | keyword |
| fortidlp.fortidlp_stream.sensor.indicators.kind |  | keyword |
| fortidlp.fortidlp_stream.sensor.indicators.tactic.id |  | keyword |
| fortidlp.fortidlp_stream.sensor.indicators.tactic.title |  | keyword |
| fortidlp.fortidlp_stream.sensor.indicators.technique.id |  | keyword |
| fortidlp.fortidlp_stream.sensor.indicators.technique.title |  | keyword |
| fortidlp.fortidlp_stream.sensor.label_ids |  | keyword |
| fortidlp.fortidlp_stream.sensor.label_names |  | keyword |
| fortidlp.fortidlp_stream.sensor.metadata.application_name |  | keyword |
| fortidlp.fortidlp_stream.sensor.metadata.content_pattern_name |  | keyword |
| fortidlp.fortidlp_stream.sensor.metadata.usb_pid |  | keyword |
| fortidlp.fortidlp_stream.sensor.metadata.usb_serial |  | keyword |
| fortidlp.fortidlp_stream.sensor.metadata.usb_vid |  | keyword |
| fortidlp.fortidlp_stream.sensor.process_info.app_identifier |  | keyword |
| fortidlp.fortidlp_stream.sensor.process_info.binary_name |  | keyword |
| fortidlp.fortidlp_stream.sensor.process_info.binary_path |  | keyword |
| fortidlp.fortidlp_stream.sensor.process_info.signed |  | boolean |
| fortidlp.fortidlp_stream.sensor.process_info.username |  | keyword |
| fortidlp.fortidlp_stream.sensor.process_info.uuid |  | keyword |
| fortidlp.fortidlp_stream.sensor.requested_actions |  | keyword |
| fortidlp.fortidlp_stream.sensor.score |  | long |
| fortidlp.fortidlp_stream.sensor.sensor_type |  | keyword |
| fortidlp.fortidlp_stream.sensor.suppressed_actions |  | keyword |
| fortidlp.fortidlp_stream.sensor.tags |  | keyword |
| fortidlp.fortidlp_stream.sensor.tenant_id |  | keyword |
| fortidlp.fortidlp_stream.sensor.tenant_name |  | keyword |
| fortidlp.fortidlp_stream.sensor.tenant_origin |  | keyword |
| fortidlp.fortidlp_stream.sensor.timestamp |  | keyword |
| fortidlp.fortidlp_stream.sensor.uuid |  | keyword |
| host.containerized | If the host is a container. | boolean |
| host.os.build | OS build information. | keyword |
| host.os.codename | OS codename, if any. | keyword |
| input.type | Type of Filebeat input. | keyword |
| log.file.device_id | ID of the device containing the filesystem where the file resides. | keyword |
| log.file.fingerprint | The sha256 fingerprint identity of the file when fingerprinting is enabled. | keyword |
| log.file.idxhi | The high-order part of a unique identifier that is associated with a file. (Windows-only) | keyword |
| log.file.idxlo | The low-order part of a unique identifier that is associated with a file. (Windows-only) | keyword |
| log.file.inode | Inode number of the log file. | keyword |
| log.file.vol | The serial number of the volume that contains a file. (Windows-only) | keyword |
| log.flags | Flags for the log file. | keyword |
| log.offset | Offset of the entry in the log file. | long |

